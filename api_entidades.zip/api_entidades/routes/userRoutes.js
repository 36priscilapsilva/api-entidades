const express = require('express');
const { getProfile, createPost } = require('../controllers/userController');
const { protect } = require('../middleware/authMiddleware');
const router = express.Router();

router.get('/me', protect, getProfile); 
router.post('/posts', protect, createPost); 

module.exports = router;
